﻿namespace BackgroundService.Models
{
    public class Message
    {
        public int Id { get; set; }
        public string Texte { get; set; }
    }
}
